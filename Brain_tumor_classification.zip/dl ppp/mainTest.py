import cv2
from keras.models import load_model
from PIL import Image
import numpy as np

model=load_model('BrainTumor10EpochsCategorical.h5')

image=cv2.imread('D:\\dl ppp\\pred\\pred5.jpg')

img=Image.fromarray(image, 'RGB')

img=img.resize((64,64))

img=np.array(img)

input_img=np.expand_dims(img, axis=0)

# Use model.predict to get the predicted probabilities for each class
predicted_probabilities = model.predict(input_img)

# Find the index of the class with the highest probability
predicted_class_index = np.argmax(predicted_probabilities)

def get_className(classNo):
    if classNo == 0:
        return "No Brain Tumor"
    elif classNo == 1:
        return "Yes Brain Tumor"


# Get the class name corresponding to the predicted class index
predicted_class = get_className(predicted_class_index)

print("Predicted Class:", predicted_class)
#print(result)




